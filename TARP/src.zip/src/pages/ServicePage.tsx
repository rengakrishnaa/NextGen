import React, { useState, useEffect } from 'react';
import Web3 from 'web3';
import Navbar from '../Components/Navbar';
import Sidebar from '../Components/Sidebar';
import { Box, Typography, Button, TextField } from '@mui/material';
import ApplicantStorage from '../contracts/ApplicantStorageInte.json'; // ABI file

const ServicePage: React.FC = () => {
  const [applicantData, setApplicantData] = useState({
    name: '',
    email: '',
    phone: '',
    addressDetails: ''
  });

  const [web3, setWeb3] = useState<Web3 | null>(null);
  const [contract, setContract] = useState<any>(null);

  useEffect(() => {
    // Load Web3 and contract when the component mounts
    const loadBlockchainData = async () => {
      const web3Instance = new Web3(Web3.givenProvider || "http://localhost:8545");
      setWeb3(web3Instance);

      // Manually specify the deployed contract address
      const contractAddress = 'YOUR_CONTRACT_ADDRESS'; // Replace with actual deployed contract address
      const contractInstance = new web3Instance.eth.Contract(
        ApplicantStorage.abi,
        contractAddress
      );
      setContract(contractInstance);
    };

    loadBlockchainData();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setApplicantData(prevData => ({
      ...prevData,
      [name]: value,
    }));
  };

  const registerApplicant = async () => {
    if (web3 && contract) {
      const accounts = await web3.eth.getAccounts();
      await contract.methods.setApplicant(
        applicantData.name,
        applicantData.email,
        applicantData.phone,
        applicantData.addressDetails
      ).send({ from: accounts[0] });
      console.log('Applicant registered successfully!');
    } else {
      console.error('Web3 or contract is not loaded.');
    }
  };

  const handleSubmit = () => {
    registerApplicant();
  };

  return (
    <div>
      <Navbar />
      <Box sx={{ display: 'flex' }}>
        <Sidebar />
        <Box sx={{ flex: 1, padding: '20px' }}>
          <Typography variant="h4">Service Details</Typography>
          <TextField
            name="name"
            label="Name"
            value={applicantData.name}
            onChange={handleChange}
            fullWidth
            sx={{ marginTop: '20px' }}
          />
          <TextField
            name="email"
            label="Email"
            value={applicantData.email}
            onChange={handleChange}
            fullWidth
            sx={{ marginTop: '20px' }}
          />
          <TextField
            name="phone"
            label="Phone"
            value={applicantData.phone}
            onChange={handleChange}
            fullWidth
            sx={{ marginTop: '20px' }}
          />
          <TextField
            name="addressDetails"
            label="Address Details"
            value={applicantData.addressDetails}
            onChange={handleChange}
            fullWidth
            sx={{ marginTop: '20px' }}
          />
          <Button variant="contained" sx={{ marginTop: '20px' }} onClick={handleSubmit}>
            Apply
          </Button>
        </Box>
      </Box>
    </div>
  );
};

export default ServicePage;
