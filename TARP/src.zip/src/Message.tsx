

const Message = () => {
  return (
    <div>
      <h1>Hello</h1>
    </div>
  )
}

export default Message