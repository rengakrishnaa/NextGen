import axios from 'axios';

// Function to get the CSRF token from cookies
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Set up Axios defaults
axios.defaults.withCredentials = true;  // Allow credentials to be sent
axios.defaults.headers.common['X-CSRFToken'] = getCookie('csrftoken');  // Set CSRF token

export default axios;
