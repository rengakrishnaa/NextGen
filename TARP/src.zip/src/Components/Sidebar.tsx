import React, { useEffect, useState } from 'react';
import { Avatar, Typography, Box } from '@mui/material';
import axios from 'axios';

interface UserDetails {
  name: string;
  phone: string;
  email: string;
  address: string;
}

const Sidebar: React.FC = () => {
  const [userDetails, setUserDetails] = useState<UserDetails | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const getCsrfToken = () => {
    return document.cookie.split('; ')
      .find(row => row.startsWith('csrftoken='))?.split('=')[1];
  };

  const fetchUserDetails = async () => {
    const token = localStorage.getItem('access_token');
    const wallet_address = localStorage.getItem('wallet_address');
    console.log("Token:", token, "Wallet Address:", wallet_address);

    if (!token || !wallet_address) {
      setError('No token or wallet address found');
      return;
    }

    try {
      const response = await axios.get(`http://localhost:8000/api/user-details/${wallet_address}/`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'X-CSRFToken': getCsrfToken(),
        },
        withCredentials: true,
      });
      console.log("Response Data:", response.data);
        setUserDetails(response.data);
      }catch (error) {
      console.error('Error fetching user details', error);
      setError('Failed to fetch user details');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUserDetails();
  }, []);

  return (
    <Box
      sx={{
        width: '90px',
        padding: '90px',
        borderRight: '2px solid gray',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '10px',
      }}
    >
      {isLoading ? (
        <Typography>Loading...</Typography>
      ) : error ? (
        <Typography color="error">{error}</Typography>
      ) : (
        <>
          <Avatar sx={{ width: 100, height: 100 }} />
          <Typography variant="h6" align="center">
            {userDetails?.name || 'Name'}
          </Typography>
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              width: '100%',
              textAlign: 'center',
            }}
          >
            <Typography>Phone: {userDetails?.phone || 'Phone'}</Typography>
            <Typography>Email: {userDetails?.email || 'Email'}</Typography>
            <Typography>Address: {userDetails?.address || 'Address'}</Typography>
          </Box>
        </>
      )}
    </Box>
  );
};

export default Sidebar;
