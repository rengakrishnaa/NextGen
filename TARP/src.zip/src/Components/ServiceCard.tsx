import React from 'react';
import { Card, CardContent, Typography, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';

interface ServiceCardProps {
  id: number;
  title: string;
  description: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ id, title, description }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/service/${id}`);
  };

  return (
    <Card sx={{ margin: '25px' }}>
      <CardContent>
        <Typography variant="h5">{title}</Typography>
        <Typography>{description}</Typography>
        <Button variant="contained" onClick={handleClick}>View More</Button>
      </CardContent>
    </Card>
  );
};

export default ServiceCard;
